using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.Collections;
using System.Data.SqlClient;
using System.IO;
using MySql.Data.MySqlClient;

namespace WebAPI
{

    [ApiController]
    public class BoardController : ControllerBase
    {
        [Route("Board/select")]
        [HttpGet]
        public ActionResult<ArrayList> Get()
        {
            DataBase dataBase = new DataBase();
            MySqlDataReader sdr = dataBase.Reader("sp_Board_Select");
            ArrayList list = new ArrayList();

            while (sdr.Read())
            {
                string[] arr = new string[sdr.FieldCount];
                for (int i = 0; i < sdr.FieldCount; i++)
                {
                    arr[i] = sdr.GetValue(i).ToString();
                }
                list.Add(arr);
            }
            dataBase.ReaderClose(sdr);

            return list;
        }

        [Route("Board/insert")]
        [HttpPost]
        public ActionResult<string> Insert([FromForm] string title,[FromForm] string contents,[FromForm] string USER,[FromForm] string passwd)
        {
            Hashtable ht = new Hashtable();
            ht.Add("_title",title);
            ht.Add("_contents",contents);
            ht.Add("_user",USER);
            ht.Add("_passwd",passwd);

            DataBase dataBase = new DataBase();

            if(dataBase.NonQuery("sp_Board_insert",ht))
            {
                return "1";
            }
            else
            {
                return "0";
            }
        }


        [Route("Board/delete")]
        [HttpPost]
        public ActionResult<string> Delete([FromForm]string no)
        {
            Hashtable ht = new Hashtable();
            ht.Add("_no",no);

            DataBase dataBase = new DataBase();

            if(dataBase.NonQuery("sp_Board_Delete",ht))
            {
                return "1";
            }
            else
            {
                return "0";
            }
        }


        // [Route("Board/selectList")]
        // [HttpPost]
        // public ActionResult<string> sp_Board_SelectList([FromForm] string no)
        // {
        //     //string param = string.Format("{0} : {1}",name,age);
        //     // Console.WriteLine("Insert" + param);

        //     Hashtable ht = new Hashtable();

        //     DataBase dataBase = new DataBase();

        //     if(dataBase.NonQuery("sp_Board_SelectList",ht))
        //     {
        //         return "1";
        //     }
        //     else
        //     {
        //         return "0";
        //     }
        // }
    }
}
