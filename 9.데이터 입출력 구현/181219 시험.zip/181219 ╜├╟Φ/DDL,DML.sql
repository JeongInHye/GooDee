USE test2;

TRUNCATE table Board;

create TABLE Board (
	no INT NOT NULL AUTO_INCREMENT,
	title VARCHAR(30) NOT NULL,
	contents VARCHAR(500) NULL,
	user VARCHAR(20) NOT NULL,
	passwd VARCHAR(20) NOT NULL,
	views INT NULL DEFAULT 0,
	delYn CHAR(1) NOT NULL DEFAULT 'N',
	regDate DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
	modDate DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
	PRIMARY KEY (no)
);

INSERT into Board (title,USER,passwd) VALUES ('제목-> 내용없음','정인혜','1234');
INSERT into Board (title,contents,USER,passwd) VALUES ('제목','내요오옹','정인혜','1234');
SELECT * FROM Board;

/*==============================================*/
delimiter \\
create PROCEDURE sp_Board_Select()
BEGIN
	SELECT NO,title,USER,views FROM Board WHERE delYn = 'N';
end
\\

CALL sp_Board_Select

/*==============================================*/
delimiter \\
create PROCEDURE sp_Board_insert(IN _title VARCHAR(30),IN _contents varchar(500),IN _user VARCHAR(20),IN _passwd varchar(20))
BEGIN
	if _contents ='' then
	#SELECT _contents;
		INSERT into Board (title,USER,passwd) VALUES (_title,_user,_passwd);
	else INSERT into Board (title,contents,USER,passwd) VALUES (_title,_contents,_user,_passwd);
	END if;
end
\\

call sp_Board_insert('ss','','asfd','adfs');

/*==============================================*/
delimiter \\
create PROCEDURE sp_Board_SelectList(IN _no int)
BEGIN
	SELECT contents,USER FROM Board WHERE delYn = 'N' AND NO = _no;
end
\\

CALL sp_Board_SelectList(1)

/*==============================================*/
delimiter \\
create PROCEDURE sp_Board_Search(IN _title VARCHAR(30))#,IN _contents varchar(500),IN _user VARCHAR(20))
BEGIN
	SELECT NO,title,USER,views FROM Board WHERE title = _title;
	#ELSEIF then _contents = NOT NULL then SELECT NO,title,USER,views FROM Board WHERE contents = _contents;
	#ELSE _user = NOT NULL then SELECT NO,title,USER,views FROM Board WHERE user = _user;
	#END if;
end
\\

CALL sp_Board_Search('제목')

/*==============================================*/
delimiter \\
create PROCEDURE sp_Board_Delete(IN _no int)
BEGIN
	UPDATE Board SET delYn='Y' WHERE NO = _no;
end
\\


CALL sp_Board_Delete(1)