﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _181219_시험
{
    public partial class AddForm : Form
    {
        private WebAPI api;
        private Hashtable hashtable;

        public AddForm()
        {
            InitializeComponent();
            Load += AddForm_Load;
        }

        private void AddForm_Load(object sender, EventArgs e)
        {
            MaximizeBox = false;
            MinimizeBox = false;

           
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            api = new WebAPI();

            hashtable = new Hashtable();
            hashtable.Add("title", txtTitle.Text);
            hashtable.Add("contents", txtContents.Text);
            hashtable.Add("USER", txtUser.Text);
            hashtable.Add("passwd", txtPasswd.Text);
            api.Post("http://192.168.3.31:5000/Board/insert", hashtable);

            Close();
        }
    }
}
