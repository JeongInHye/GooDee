﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _181219_시험
{
    public partial class ListviewClickForm : Form
    {
        public string no;
        private WebAPI api;
        private Hashtable hashtable;

        public ListviewClickForm(string no)
        {
            this.no = no;
            InitializeComponent();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            api = new WebAPI();
            Main main = new Main();

            hashtable = new Hashtable();
            hashtable.Add("no", no);
            api.Post("http://192.168.3.31:5000/Board/delete", hashtable);

            Close();
        }
    }
}
