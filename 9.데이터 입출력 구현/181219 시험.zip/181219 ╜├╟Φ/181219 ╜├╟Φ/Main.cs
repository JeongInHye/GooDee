﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _181219_시험
{
    public partial class Main : Form
    {
        private WebAPI api;
        public string no;
        private Hashtable hashtable;

        public Main()
        {
            InitializeComponent();
            Load += Main_Load;
        }

        public void Main_Load(object sender, EventArgs e)
        {
            api = new WebAPI();

            MaximizeBox = false;
            MinimizeBox = false;

            listView1.MouseClick += ListView1_MouseClick;

            api.ListView("http://192.168.3.31:5000/Board/select", listView1);
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            api = new WebAPI();

            hashtable = new Hashtable();
            hashtable.Add("title", textBox1.Text);
            listView1.Items.Clear();
            api.Search("http://192.168.3.31:5000/Board/search",hashtable, listView1);
        }

        private void ListView1_MouseClick(object sender, MouseEventArgs e)
        {
            ListView lv = (ListView)sender;
            ListView.SelectedListViewItemCollection slv = lv.SelectedItems;
            for (int i = 0; i < slv.Count; i++)
            {
                ListViewItem item = slv[i];
                no = item.SubItems[0].Text;
            }

            ListviewClickForm listviewClickForm = new ListviewClickForm(no);
            listviewClickForm.ShowDialog();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            AddForm addForm = new AddForm();
            addForm.ShowDialog();

            listView1.Items.Clear();

            api = new WebAPI();

            api.ListView("http://192.168.3.31:5000/Board/select", listView1);
        }
    }
}
