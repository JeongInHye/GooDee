﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _181219_시험
{
    class WebAPI
    {
        public bool ListView(string url, ListView listView)
        {
            try
            {
                WebClient wc = new WebClient();
                Stream stream = wc.OpenRead(url);
                StreamReader sr = new StreamReader(stream);
                string result = sr.ReadToEnd();
                ArrayList list = JsonConvert.DeserializeObject<ArrayList>(result);
                listView.Items.Clear();
                for (int i = 0; i < list.Count; i++)
                {
                    JArray jArray = (JArray)list[i];
                    string[] arr = new string[jArray.Count];
                    for (int j = 0; j < jArray.Count; j++)
                    {
                        //MessageBox.Show(jArray[j].ToString());
                        arr[j] = jArray[j].ToString();
                    }
                    listView.Items.Add(new ListViewItem(arr));
                }
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool Search(string url,Hashtable ht,ListView listView)
        {
            try
            {
                WebClient wc = new WebClient();
                NameValueCollection nameValue = new NameValueCollection();

                foreach (DictionaryEntry data in ht)
                {
                    nameValue.Add(data.Key.ToString(), data.Value.ToString());
                }

                byte[] result = wc.UploadValues(url, "POST", nameValue);
                string resultStr = Encoding.UTF8.GetString(result);
            //    if ("1" == resultStr)
            //    {
                    try
                    {
                        Stream stream = wc.OpenRead(url);
                        StreamReader sr = new StreamReader(stream);
                        string result1 = sr.ReadToEnd();
                        ArrayList list = JsonConvert.DeserializeObject<ArrayList>(result1);
                        listView.Items.Clear();
                        for (int i = 0; i < list.Count; i++)
                        {
                            JArray jArray = (JArray)list[i];
                            string[] arr = new string[jArray.Count];
                            for (int j = 0; j < jArray.Count; j++)
                            {
                                arr[j] = jArray[j].ToString();
                            }
                            listView.Items.Add(new ListViewItem(arr));
                        }
                        return true;
                    }
                    catch
                    {
                        return false;
                    }
               // }
                //else
                //{
                //    MessageBox.Show("실패");
                //}
                //MessageBox.Show(resultStr);

                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool Post(string url, Hashtable ht)
        {
            try
            {
                WebClient wc = new WebClient();
                NameValueCollection nameValue = new NameValueCollection();

                foreach (DictionaryEntry data in ht)
                {
                    nameValue.Add(data.Key.ToString(), data.Value.ToString());
                }

                byte[] result = wc.UploadValues(url, "POST", nameValue);
                string resultStr = Encoding.UTF8.GetString(result);
                if ("1" == resultStr)
                {
                    MessageBox.Show("성공");
                }
                else
                {
                    MessageBox.Show("실패");
                }
                //MessageBox.Show(resultStr);

                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
